/**
 * Migration script to fix Farm status field
 * Converts string status values to proper object structure
 */

const mongoose = require('mongoose');
require('dotenv').config();

const Farm = require('../models/Farm');

async function fixFarmStatus() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    
    console.log('Connected to MongoDB');
    
    // Find all farms where status is a string
    const farmsWithStringStatus = await Farm.find({
      $or: [
        { status: { $type: 'string' } },
        { 'status.isActive': { $exists: false } }
      ]
    });
    
    console.log(`Found ${farmsWithStringStatus.length} farms with string status`);
    
    for (const farm of farmsWithStringStatus) {
      console.log(`Processing farm: ${farm._id}`);
      
      // Check if status is a string
      if (typeof farm.status === 'string') {
        console.log(`  - Status is string: "${farm.status}"`);
        
        // Convert string status to proper object
        const newStatus = {
          isActive: farm.status === 'active' || farm.status === 'true',
          lastUpdated: new Date(),
          verificationStatus: 'unverified',
          dataQuality: {
            completeness: 0,
            accuracy: 'unknown'
          }
        };
        
        // Update the farm
        await Farm.updateOne(
          { _id: farm._id },
          { 
            $set: { 
              status: newStatus 
            }
          }
        );
        
        console.log(`  - Updated status to object`);
      } else if (!farm.status || typeof farm.status !== 'object') {
        console.log(`  - Status is missing or invalid`);
        
        // Set default status object
        const defaultStatus = {
          isActive: true,
          lastUpdated: new Date(),
          verificationStatus: 'unverified',
          dataQuality: {
            completeness: 0,
            accuracy: 'unknown'
          }
        };
        
        // Update the farm
        await Farm.updateOne(
          { _id: farm._id },
          { 
            $set: { 
              status: defaultStatus 
            }
          }
        );
        
        console.log(`  - Set default status object`);
      }
    }
    
    // Also fix farms where status object is missing required fields
    const farmsWithIncompleteStatus = await Farm.find({
      status: { $type: 'object' },
      $or: [
        { 'status.isActive': { $exists: false } },
        { 'status.lastUpdated': { $exists: false } },
        { 'status.verificationStatus': { $exists: false } }
      ]
    });
    
    console.log(`Found ${farmsWithIncompleteStatus.length} farms with incomplete status object`);
    
    for (const farm of farmsWithIncompleteStatus) {
      console.log(`Processing farm: ${farm._id}`);
      
      const currentStatus = farm.status || {};
      const updatedStatus = {
        isActive: currentStatus.isActive !== undefined ? currentStatus.isActive : true,
        lastUpdated: currentStatus.lastUpdated || new Date(),
        verificationStatus: currentStatus.verificationStatus || 'unverified',
        dataQuality: {
          completeness: currentStatus.dataQuality?.completeness || 0,
          accuracy: currentStatus.dataQuality?.accuracy || 'unknown',
          lastValidated: currentStatus.dataQuality?.lastValidated || null
        }
      };
      
      // Update the farm
      await Farm.updateOne(
        { _id: farm._id },
        { 
          $set: { 
            status: updatedStatus 
          }
        }
      );
      
      console.log(`  - Updated incomplete status object`);
    }
    
    console.log('Migration completed successfully!');
    
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}

// Run the migration
fixFarmStatus(); 